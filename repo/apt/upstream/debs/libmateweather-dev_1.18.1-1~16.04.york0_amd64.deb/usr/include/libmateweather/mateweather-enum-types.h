
/* Generated data (by glib-mkenums) */

#ifndef __MATEWEATHER_ENUM_TYPES_H__
#define __MATEWEATHER_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "mateweather-location.h" */
GType mateweather_location_level_get_type (void) G_GNUC_CONST;
#define MATEWEATHER_TYPE_LOCATION_LEVEL (mateweather_location_level_get_type ())
G_END_DECLS

#endif /* __MATEWEATHER_ENUM_TYPES_H__ */

/* Generated data ends here */

