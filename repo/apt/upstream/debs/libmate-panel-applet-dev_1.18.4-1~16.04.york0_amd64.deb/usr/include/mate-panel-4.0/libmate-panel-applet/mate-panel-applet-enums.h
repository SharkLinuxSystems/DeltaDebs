


#ifndef __MATE_PANEL_APPLET_ENUMS_H__
#define __MATE_PANEL_APPLET_ENUMS_H__

#ifdef __cplusplus
extern "C" {
#endif


/* --- ../libmate-panel-applet/mate-panel-applet.h --- */
#define PANEL_TYPE_MATE_PANEL_APPLET_ORIENT mate_panel_applet_orient_get_type()
GType mate_panel_applet_orient_get_type (void);
#define PANEL_TYPE_MATE_PANEL_APPLET_BACKGROUND_TYPE mate_panel_applet_background_type_get_type()
GType mate_panel_applet_background_type_get_type (void);
#define PANEL_TYPE_MATE_PANEL_APPLET_FLAGS mate_panel_applet_flags_get_type()
GType mate_panel_applet_flags_get_type (void);
#ifdef __cplusplus
}
#endif

#endif /* __MATE_PANEL_APPLET_ENUMS_H__ */



