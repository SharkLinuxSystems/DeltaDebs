case $LANGUAGE in
  zh_CN*)
    export UNZIP="-O GBK"
    export ZIPINFO="-O GBK"
    ;;
esac
