pref("browser.search.selectedEngine", "file:/usr/share/ubuntukylin-default-settings/ubuntukylin-browser-defaults.properties");
pref("browser.search.defaultenginename", "file:/usr/share/ubuntukylin-default-settings/ubuntukylin-browser-defaults.properties");
pref("browser.search.order.1", "file:/usr/share/ubuntukylin-default-settings/ubuntukylin-browser-defaults.properties");
pref("keyword.URL", "file:/usr/share/ubuntukylin-default-settings/ubuntukylin-browser-defaults.properties");
// pref("browser.startup.homepage", "file:/usr/share/ubuntukylin-default-settings/ubuntukylin-browser-defaults.properties");
